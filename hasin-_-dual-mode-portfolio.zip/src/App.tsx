import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import { CODING_CONTENT, LIFE_CONTENT, CONTACT_INFO } from './constants';
import { 
  Code2, 
  Heart, 
  Github, 
  Linkedin, 
  Mail, 
  ExternalLink, 
  Terminal, 
  Palette, 
  Cpu, 
  Layers,
  Award,
  ChevronRight,
  Menu,
  X,
  Sun,
  Moon,
  Sparkles,
  Phone
} from 'lucide-react';
import Typewriter from 'typewriter-effect';

// --- Components ---

const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      const target = e.target as HTMLElement;
      setIsPointer(window.getComputedStyle(target).cursor === 'pointer');
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <motion.div
      className="custom-cursor hidden md:block"
      animate={{
        x: position.x - 10,
        y: position.y - 10,
        scale: isPointer ? 2.5 : 1,
      }}
      transition={{ type: 'spring', damping: 30, stiffness: 200, mass: 0.5 }}
    />
  );
};

const IntroLoader = ({ onComplete }: { onComplete: () => void }) => {
  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-[#050505] text-white font-mono overflow-hidden"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -100 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      <div className="text-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-2xl md:text-4xl mb-4"
        >
          <Typewriter
            options={{
              strings: ['Initializing Hasin F...', 'Loading Systems...', 'Ready.'],
              autoStart: true,
              loop: false,
              delay: 50,
            }}
            onInit={(typewriter) => {
              typewriter
                .pauseFor(2000)
                .callFunction(() => onComplete())
                .start();
            }}
          />
        </motion.div>
        <motion.div 
          className="w-48 h-1 bg-white/10 mx-auto rounded-full overflow-hidden"
          initial={{ width: 0 }}
          animate={{ width: 192 }}
          transition={{ duration: 2, ease: "easeInOut" }}
        >
          <motion.div 
            className="h-full bg-blue-500"
            initial={{ x: '-100%' }}
            animate={{ x: '0%' }}
            transition={{ duration: 2, ease: "easeInOut" }}
          />
        </motion.div>
      </div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [mode, setMode] = useState<'coding' | 'life'>('coding');
  const [theme, setTheme] = useState<'dark' | 'light' | 'colorful'>('dark');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = (window.scrollY / totalHeight) * 100;
      setScrollProgress(progress);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMode = () => {
    setMode(prev => prev === 'coding' ? 'life' : 'coding');
    // Auto-switch theme based on mode if it's currently the default for that mode
    if (mode === 'coding') {
      setTheme('light');
    } else {
      setTheme('dark');
    }
  };

  const currentThemeClass = cn(
    mode === 'coding' ? 'font-display' : 'font-alt',
    theme === 'dark' && 'bg-[#050505] text-white',
    theme === 'light' && 'bg-[#fdfcfb] text-slate-900',
    theme === 'colorful' && 'bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 text-white'
  );

  return (
    <div className={cn("min-h-screen overflow-x-hidden selection:bg-blue-500 selection:text-white", currentThemeClass)}>
      <CustomCursor />
      
      <AnimatePresence>
        {!isLoaded && <IntroLoader onComplete={() => setIsLoaded(true)} />}
      </AnimatePresence>

      {isLoaded && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          {/* Scroll Progress Bar */}
          <div className="fixed top-0 left-0 w-full h-1 z-[60]">
            <motion.div 
              className={cn(
                "h-full",
                mode === 'coding' ? "bg-blue-500" : "bg-pink-500"
              )}
              style={{ width: `${scrollProgress}%` }}
            />
          </div>

          {/* Navigation */}
          <nav className="fixed top-0 left-0 w-full z-50 px-6 py-4 flex justify-between items-center">
            <motion.div 
              className="text-2xl font-bold tracking-tighter"
              whileHover={{ scale: 1.05 }}
            >
              {mode === 'coding' ? 'F_HASIN' : 'f.hasin'}
            </motion.div>

            <div className="hidden md:flex items-center gap-8">
              {['About', 'Skills', 'Projects', 'Contact'].map((item) => (
                <a 
                  key={item} 
                  href={`#${item.toLowerCase()}`}
                  className="text-sm font-medium uppercase tracking-widest hover:opacity-50 transition-opacity"
                >
                  {item}
                </a>
              ))}
            </div>

            <div className="flex items-center gap-4">
              {/* Theme Switcher */}
              <div className="flex bg-white/5 backdrop-blur-md p-1 rounded-full border border-white/10">
                <button onClick={() => setTheme('dark')} className={cn("p-2 rounded-full transition-all cursor-pointer", theme === 'dark' && "bg-white/20")}><Moon size={16} /></button>
                <button onClick={() => setTheme('light')} className={cn("p-2 rounded-full transition-all cursor-pointer", theme === 'light' && "bg-white/20")}><Sun size={16} /></button>
                <button onClick={() => setTheme('colorful')} className={cn("p-2 rounded-full transition-all cursor-pointer", theme === 'colorful' && "bg-white/20")}><Sparkles size={16} /></button>
              </div>

              {/* Mode Toggle */}
              <button 
                onClick={toggleMode}
                className={cn(
                  "relative flex items-center gap-2 px-4 py-2 rounded-full font-bold text-xs uppercase tracking-tighter transition-all duration-500 cursor-pointer",
                  mode === 'coding' 
                    ? "bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]" 
                    : "bg-pink-500 text-white shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                )}
              >
                {mode === 'coding' ? <Code2 size={16} /> : <Heart size={16} />}
                <span>{mode === 'coding' ? 'Coding Mode' : 'Life Mode'}</span>
              </button>

              <button className="md:hidden cursor-pointer" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </nav>

          {/* Mobile Menu */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, x: '100%' }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: '100%' }}
                className="fixed inset-0 z-[55] bg-black/95 flex flex-col items-center justify-center gap-8"
              >
                {['About', 'Skills', 'Projects', 'Contact'].map((item) => (
                  <a 
                    key={item} 
                    href={`#${item.toLowerCase()}`}
                    onClick={() => setIsMenuOpen(false)}
                    className="text-3xl font-bold uppercase tracking-widest"
                  >
                    {item}
                  </a>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main Content */}
          <main>
            <AnimatePresence mode="wait">
              {mode === 'coding' ? (
                <CodingView key="coding" />
              ) : (
                <LifeView key="life" />
              )}
            </AnimatePresence>
          </main>

          {/* Footer */}
          <footer className="py-12 px-6 border-t border-white/10">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
              <div className="text-center md:text-left">
                <div className="text-xl font-bold mb-2">F Hasin</div>
                <div className="text-sm opacity-50">© 2026 All Rights Reserved.</div>
              </div>
              <div className="flex gap-6">
                <a href={`https://${CONTACT_INFO.github}`} target="_blank" rel="noreferrer" className="hover:text-blue-500 transition-colors"><Github /></a>
                <a href={`https://${CONTACT_INFO.linkedin}`} target="_blank" rel="noreferrer" className="hover:text-blue-500 transition-colors"><Linkedin /></a>
                <a href={`mailto:${CONTACT_INFO.email}`} className="hover:text-blue-500 transition-colors"><Mail /></a>
                <a href={`tel:${CONTACT_INFO.phone}`} className="hover:text-blue-500 transition-colors"><Phone /></a>
              </div>
            </div>
          </footer>
        </motion.div>
      )}
    </div>
  );
}

// --- Coding View ---

const CodingView = () => {
  return (
    <motion.div
      initial={{ opacity: 0, filter: 'blur(20px)' }}
      animate={{ opacity: 1, filter: 'blur(0px)' }}
      exit={{ opacity: 0, filter: 'blur(20px)' }}
      transition={{ duration: 0.8 }}
      className="pt-32"
    >
      {/* Hero */}
      <section className="px-6 min-h-[80vh] flex flex-col justify-center max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <motion.div 
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-mono mb-6"
            >
              <Terminal size={14} />
              <span>SYSTEM_READY</span>
            </motion.div>
            <motion.h1 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-6xl md:text-8xl font-bold tracking-tighter mb-6 leading-none"
            >
              I'm <span className="text-blue-500">{CODING_CONTENT.name}</span>
            </motion.h1>
            <div className="text-xl md:text-2xl font-mono opacity-70 mb-8 h-8">
              <Typewriter
                options={{
                  strings: CODING_CONTENT.roles,
                  autoStart: true,
                  loop: true,
                }}
              />
            </div>
            <div className="flex gap-4">
              <button className="px-8 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-bold transition-all neo-glow cursor-pointer">View Projects</button>
              <button className="px-8 py-3 border border-white/20 hover:bg-white/5 rounded-lg font-bold transition-all cursor-pointer">Contact Me</button>
            </div>
          </div>
          <div className="relative">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="aspect-square rounded-2xl overflow-hidden glass p-4"
            >
              <img 
                src="https://picsum.photos/seed/hasin_f/600/600" 
                alt="Profile" 
                className="w-full h-full object-cover rounded-xl grayscale hover:grayscale-0 transition-all duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-blue-500/20 blur-3xl rounded-full" />
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-purple-500/20 blur-3xl rounded-full" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12">
          <div className="md:col-span-1">
            <h2 className="text-4xl font-bold tracking-tighter mb-4">ABOUT_ME</h2>
            <div className="w-12 h-1 bg-blue-500 rounded-full" />
          </div>
          <div className="md:col-span-2">
            <p className="text-xl leading-relaxed opacity-70 font-mono">
              {CODING_CONTENT.about}
            </p>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section id="skills" className="py-24 px-6 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold tracking-tighter mb-16 text-center">TECH_STACK</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {Object.entries(CODING_CONTENT.skills).map(([category, items], idx) => (
              <motion.div 
                key={category}
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="glass p-6 rounded-2xl"
              >
                <h3 className="text-blue-400 font-mono text-xs uppercase mb-4 tracking-widest">{category}</h3>
                <div className="flex flex-wrap gap-2">
                  {items.map(skill => (
                    <span key={skill} className="px-3 py-1 bg-white/5 rounded-full text-sm border border-white/10">{skill}</span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects */}
      <section id="projects" className="py-24 px-6 max-w-7xl mx-auto">
        <h2 className="text-4xl font-bold tracking-tighter mb-16">FEATURED_PROJECTS</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {CODING_CONTENT.projects.map((project, idx) => (
            <motion.div 
              key={project.title}
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative rounded-2xl overflow-hidden glass"
            >
              <div className="aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-sm opacity-60 mb-4 line-clamp-2">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.map(t => (
                    <span key={t} className="text-[10px] px-2 py-0.5 bg-blue-500/10 text-blue-400 border border-blue-500/20 rounded uppercase">{t}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Services */}
      <section className="py-24 px-6 bg-white/[0.02]">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold tracking-tighter mb-16 text-center">SERVICES</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {CODING_CONTENT.services.map((service, idx) => (
              <motion.div 
                key={service.title}
                whileHover={{ y: -10 }}
                className="p-8 rounded-2xl glass border-l-4 border-l-blue-500"
              >
                <h3 className="text-xl font-bold mb-4">{service.title}</h3>
                <p className="opacity-60">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements & Awards */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-3xl font-bold tracking-tighter mb-8 flex items-center gap-3">
              <Award className="text-blue-500" /> ACHIEVEMENTS
            </h2>
            <div className="space-y-4">
              {CODING_CONTENT.achievements.map((item, idx) => (
                <div key={idx} className="flex items-start gap-4 p-4 glass rounded-xl">
                  <ChevronRight className="text-blue-500 mt-1" size={18} />
                  <p className="font-mono text-sm">{item}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h2 className="text-3xl font-bold tracking-tighter mb-8 flex items-center gap-3">
              <Layers className="text-blue-500" /> CERTIFICATIONS
            </h2>
            <div className="grid grid-cols-1 gap-4">
              {CODING_CONTENT.certifications.map((item, idx) => (
                <div key={idx} className="p-4 glass rounded-xl border-r-4 border-r-blue-500/30">
                  <p className="font-mono text-sm">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-24 px-6 max-w-3xl mx-auto text-center">
        <h2 className="text-5xl font-bold tracking-tighter mb-8">GET_IN_TOUCH</h2>
        <p className="text-xl opacity-60 mb-12 font-mono">Ready to build something amazing? Let's connect.</p>
        <form className="space-y-6 text-left">
          <div className="grid md:grid-cols-2 gap-6">
            <input type="text" placeholder="NAME" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-blue-500 outline-none transition-all" />
            <input type="email" placeholder="EMAIL" className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-blue-500 outline-none transition-all" />
          </div>
          <textarea placeholder="MESSAGE" rows={5} className="w-full bg-white/5 border border-white/10 rounded-xl p-4 focus:border-blue-500 outline-none transition-all"></textarea>
          <button className="w-full py-4 bg-blue-600 hover:bg-blue-700 rounded-xl font-bold transition-all neo-glow cursor-pointer">SEND_MESSAGE</button>
        </form>
      </section>
    </motion.div>
  );
};

// --- Life View ---

const LifeView = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 1.1 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.8 }}
      className="pt-32"
    >
      {/* Hero */}
      <section className="px-6 min-h-[90vh] flex flex-col justify-center items-center text-center max-w-5xl mx-auto relative">
        <motion.div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-pink-500/10 blur-[120px] rounded-full -z-10"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        
        <motion.h1 
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-7xl md:text-9xl font-serif italic mb-8 leading-tight"
        >
          {LIFE_CONTENT.tagline}
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-2xl mb-12"
        >
          <img 
            src="https://picsum.photos/seed/hasin_creative/400/400" 
            alt="Profile" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>

        <motion.p 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-xl md:text-2xl max-w-2xl opacity-60 font-alt"
        >
          I believe in the power of aesthetic utility. Every design is a conversation between the user and the idea.
        </motion.p>
      </section>

      {/* About */}
      <section id="about" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-24 items-center">
          <div className="relative">
            <div className="aspect-[4/5] rounded-[40px] overflow-hidden shadow-2xl">
              <img 
                src="https://picsum.photos/seed/hasin_story/800/1000" 
                alt="Story" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-white p-6 rounded-3xl shadow-xl hidden md:block">
              <p className="text-xs font-bold uppercase tracking-widest text-pink-500 mb-2">My Philosophy</p>
              <p className="text-sm italic font-serif">"Simplicity is the ultimate sophistication."</p>
            </div>
          </div>
          <div>
            <h2 className="text-5xl font-serif mb-8">The Story</h2>
            <p className="text-xl leading-relaxed opacity-70 font-alt mb-8">
              {LIFE_CONTENT.about}
            </p>
            <div className="flex flex-wrap gap-4">
              {LIFE_CONTENT.uxSkills.map(skill => (
                <span key={skill} className="px-6 py-2 rounded-full border border-pink-200 text-pink-600 font-medium text-sm">{skill}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Gallery */}
      <section id="projects" className="py-32 px-6 bg-pink-50/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <h2 className="text-6xl font-serif">Selected Works</h2>
            <p className="max-w-xs text-sm opacity-50 font-alt uppercase tracking-widest">A collection of visual explorations and user-centric solutions.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            {LIFE_CONTENT.portfolio.map((item, idx) => (
              <motion.div 
                key={item.title}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group"
              >
                <div className="aspect-[3/4] rounded-[32px] overflow-hidden mb-6 relative">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-pink-500 shadow-xl">
                      <ExternalLink size={24} />
                    </div>
                  </div>
                </div>
                <h3 className="text-2xl font-serif mb-1">{item.title}</h3>
                <p className="text-sm opacity-40 font-alt uppercase tracking-widest">{item.category}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-32 px-6 max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-16">
          {LIFE_CONTENT.services.map((service, idx) => (
            <div key={service.title} className="text-center">
              <div className="w-20 h-20 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-8 text-pink-500">
                {idx === 0 ? <Palette size={32} /> : idx === 1 ? <Sparkles size={32} /> : <Cpu size={32} />}
              </div>
              <h3 className="text-3xl font-serif mb-4">{service.title}</h3>
              <p className="opacity-60 font-alt">{service.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Awards */}
      <section className="py-32 px-6 bg-slate-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-pink-500/20 blur-[150px] rounded-full" />
        <div className="max-w-7xl mx-auto relative z-10">
          <h2 className="text-5xl font-serif mb-16 text-center">Recognition</h2>
          <div className="grid md:grid-cols-2 gap-8">
            {LIFE_CONTENT.awards.map((award, idx) => (
              <div key={idx} className="p-10 border border-white/10 rounded-[40px] hover:bg-white/5 transition-colors flex justify-between items-center group">
                <div>
                  <h3 className="text-3xl font-serif mb-2">{award.title}</h3>
                  <p className="opacity-40 font-alt uppercase tracking-widest text-sm">{award.issuer}</p>
                </div>
                <div className="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-pink-500 group-hover:border-pink-500 transition-all">
                  <Award size={20} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-32 px-6 max-w-4xl mx-auto text-center">
        <h2 className="text-7xl font-serif mb-8">Let's Create.</h2>
        <p className="text-xl opacity-60 mb-16 font-alt">Open for collaborations and creative projects.</p>
        <div className="flex flex-col md:flex-row justify-center gap-8">
          <a href={`mailto:${CONTACT_INFO.email}`} className="px-12 py-5 bg-pink-500 text-white rounded-full font-bold text-lg shadow-2xl hover:bg-pink-600 transition-all cursor-pointer">Start a Project</a>
          <div className="flex items-center justify-center gap-6">
            <a href={`https://${CONTACT_INFO.github}`} className="w-14 h-14 rounded-full border border-pink-200 flex items-center justify-center text-pink-500 hover:bg-pink-50 transition-all cursor-pointer"><Github /></a>
            <a href={`https://${CONTACT_INFO.linkedin}`} className="w-14 h-14 rounded-full border border-pink-200 flex items-center justify-center text-pink-500 hover:bg-pink-50 transition-all cursor-pointer"><Linkedin /></a>
            <a href={`tel:${CONTACT_INFO.phone}`} className="w-14 h-14 rounded-full border border-pink-200 flex items-center justify-center text-pink-500 hover:bg-pink-50 transition-all cursor-pointer"><Phone /></a>
          </div>
        </div>
      </section>
    </motion.div>
  );
};
