export const CODING_CONTENT = {
  name: "F Hasin",
  roles: ["Full Stack Developer", "AI Enthusiast", "Hackathon Finalist"],
  about: "Second-year BE student with interest in AI and software development. Participated in Smart India Hackathon 2025 with a Smart Tourist Monitoring System project, certified in Oracle AI Vector Search, and experienced in hackathons and paper presentations. Enthusiastic about teamwork, learning, and building practical solutions.",
  skills: {
    frontend: ["Vite", "React", "HTML", "CSS"],
    backend: ["SQL", "MongoDB", "Node.js"],
    database: ["MySQL", "MongoDB"],
    tools: ["VS Code", "GitHub", "Git", "Xampp", "Figma"]
  },
  projects: [
    {
      title: "Smart Tourist Monitoring System",
      description: "Developed a full-stack web application to monitor and manage tourist activities in real-time. Built using React.js, Node.js, HTML, CSS.",
      tech: ["React", "Node.js", "MongoDB"],
      image: "https://picsum.photos/seed/tourist/800/600"
    },
    {
      title: "AI-Based Stress Detection System",
      description: "Designed and developed an AI-driven stress detection system using AIML algorithms with a Python-based backend.",
      tech: ["Python", "React", "Node.js", "MySQL"],
      image: "https://picsum.photos/seed/stress/800/600"
    },
    {
      title: "Intelligent Building Management System",
      description: "Web-based system to monitor and control building operations such as HVAC, energy usage, and maintenance.",
      tech: ["PHP", "MySQL", "JavaScript", "HTML/CSS"],
      image: "https://picsum.photos/seed/building/800/600"
    }
  ],
  services: [
    {
      title: "Full Stack Development",
      description: "End-to-end web application development with modern tech stacks."
    },
    {
      title: "AI-based Applications",
      description: "Integrating machine learning models into functional web products."
    },
    {
      title: "Dashboard Systems",
      description: "Complex data visualization and management interfaces."
    }
  ],
  achievements: [
    "Finalist – Elite Hack 1.0 Hackathon | Conducted by Unstop",
    "Smart India Hackathon 2025 Participant"
  ],
  certifications: [
    "Oracle- AI Vector Search - Aug 2025",
    "AWS(Cloud Computing) – Course Completed (FEB 2026)",
    "NPTEL- Introduction to IOT - Jul-Oct 2025",
    "Coursera -AWS S3 Basics - Jun 2025",
    "NoviTech Solutions(Full Stack Development) – AUG 2025"
  ]
};

export const LIFE_CONTENT = {
  tagline: "Designing experiences. Building ideas.",
  about: "My journey is fueled by a blend of curiosity and creativity. I believe that every pixel tells a story and every interaction should be meaningful. Beyond code, I am a designer at heart, constantly exploring the boundaries of user experience and visual aesthetics.",
  uxSkills: ["UI/UX Design", "Figma", "Interaction Design", "User Flow", "Prototyping"],
  portfolio: [
    {
      title: "Ethereal UI Kit",
      category: "Design System",
      image: "https://picsum.photos/seed/design1/800/600"
    },
    {
      title: "Lumina App Concept",
      category: "Mobile UX",
      image: "https://picsum.photos/seed/design2/800/600"
    },
    {
      title: "Minimalist Branding",
      category: "Visual Identity",
      image: "https://picsum.photos/seed/design3/800/600"
    }
  ],
  services: [
    {
      title: "UI/UX Design",
      description: "Creating intuitive and beautiful interfaces that users love."
    },
    {
      title: "Web Design",
      description: "Aesthetic and functional websites tailored to brand identity."
    },
    {
      title: "App Interface Design",
      description: "Modern mobile experiences with a focus on usability."
    }
  ],
  awards: [
    { title: "Creative Excellence", issuer: "Design Guild" },
    { title: "UX Innovator", issuer: "Tech Awards" }
  ]
};

export const CONTACT_INFO = {
  email: "hasinfarukjan@gmail.com",
  linkedin: "linkedin.com/in/hasin-f",
  github: "github.com/hasinfarukjan2006",
  phone: "+91 9344475074"
};
